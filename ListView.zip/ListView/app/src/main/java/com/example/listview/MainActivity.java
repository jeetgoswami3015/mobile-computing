package com.example.listview;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView list;
    ArrayList<String> arrayList;
    ArrayAdapter<String> arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = findViewById(R.id.listview);
        //Adding data to arraylist
        arrayList = new ArrayList<>();
        arrayList.add("Mango");
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Guava");
        arrayList.add("Strawberry");
        arrayList.add("Grapes");
        arrayList.add("Orange");

        arrayList.add("Mango");
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Guava");
        arrayList.add("Strawberry");
        arrayList.add("Grapes");
        arrayList.add("Orange");

        arrayList.add("Mango");
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Guava");
        arrayList.add("Strawberry");
        arrayList.add("Grapes");
        arrayList.add("Orange");

        //Setting data to adapter
        arrayAdapter= new ArrayAdapter<>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                arrayList
        );

        list.setAdapter(arrayAdapter);



    }
}
package com.example.radio_button_ex;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    RadioGroup rg;
    RadioButton rb_india,rb_aus,rb_fiji,rb_canada,rb_ice;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg = findViewById(R.id.rg);
        rb_india  = findViewById(R.id.rb_india);
        rb_aus = findViewById(R.id.rb_aus);
        rb_fiji = findViewById(R.id.rb_fiji);
        rb_canada = findViewById(R.id.rb_canada);
        rb_ice = findViewById(R.id.rb_ice);

        img = findViewById(R.id.img);

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (rb_india.isChecked())
                {
                    img.setImageResource(R.drawable.india);
                }
                else if (rb_aus.isChecked())
                {
                    img.setImageResource(R.drawable.australia);
                }
                else if (rb_fiji.isChecked())
                {
                    img.setImageResource(R.drawable.fiji);
                }
                else if (rb_canada.isChecked())
                {
                    img.setImageResource(R.drawable.canada);
                }
                else if (rb_ice.isChecked())
                {
                    img.setImageResource(R.drawable.iceland);
                }
            }
        });


    }
}
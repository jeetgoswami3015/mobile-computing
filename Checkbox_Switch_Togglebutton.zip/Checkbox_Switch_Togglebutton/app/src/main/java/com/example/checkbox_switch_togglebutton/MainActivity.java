package com.example.checkbox_switch_togglebutton;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView tv;

    CheckBox cb;

    ToggleButton tb;

    Switch sw;

// All of these widgets are combined with Compound Button Instance
// All of these widgets are using Boolean value to get data of UI
// All of them can be managed by ClickListener also
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv=findViewById(R.id.textview);
        cb=findViewById(R.id.checkbox);
        tb=findViewById(R.id.toggleButton);
        sw=findViewById(R.id.switchButton);

        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    tv.setTextSize(30);

                }
                else {
                    tv.setTextSize(20);
                }
            }
        });
        tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(tb.isChecked()){
                    tv.setTextSize(30);

                }
                else {
                    tv.setTextSize(20);
                }
            }
        });

        sw.setOnCheckedChangeListener((compoundButton, b) -> {
            if(sw.isChecked()){
                tv.setTextSize(30);

            }
            else {
                tv.setTextSize(20);
            }
        });
        };

}